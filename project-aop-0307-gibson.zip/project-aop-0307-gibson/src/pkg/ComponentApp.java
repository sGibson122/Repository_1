package pkg;

public class ComponentApp {
   private String name;

   public ComponentApp(String name) {
      this.name = name;
   }

   public String getName() {
      return name;
   }
}
