package pkg;

public class DataApp {
   private String name;

   public DataApp(String name) {
      this.name = name;
   }

   public String getName() {
      return name;
   }
}
